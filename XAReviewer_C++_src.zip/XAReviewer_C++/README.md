# XAReviewer C++

医学影像阅片器（DSA/超声/CT），Python 版 [XAReviewer](https://github.com/shadowenzane/XAReviewer) 的 C++ 移植。

## 技术栈

| 库 | 用途 |
|---|---|
| Qt 6 | GUI（多视图、测量工具、暗色医疗主题） |
| DCMTK | DICOM 加载/多帧解码/PACS C-FIND |
| ITK | 高斯平滑（减影蒙片降噪） |
| OpenCV | 图像处理（伪彩 LUT、CLAHE）、图像/视频导出 |

## 功能

- DICOM 目录加载，五级回退排序（InstanceNumber → AcquisitionNumber → SOPInstanceUID → 文件名数字 → 文件大小）
- 窗宽窗位（拖拽调节 / 自动窗 / CT 预设），gamma + min-max 拉伸渲染管线
- DSA 减影（蒙片帧可选 ITK 高斯平滑）
- 10 种伪彩映射（JET/HOT/BONE/RAINBOW 等）
- 距离/角度测量（mm 物理单位，PixelSpacing 换算）
- 单视图 / 2×2 网格布局，多视图同步
- 超声增强（CLAHE）
- PNG/JPEG 图像导出、MP4 视频导出（FourCC 回退链）
- PACS 查询（C-FIND，Study 级）

## 构建

依赖：CMake ≥ 3.16、C++17 编译器、Qt 6（或 Qt 5）、DCMTK、OpenCV（core/imgproc/imgcodecs/videoio）、ITK。

```bash
# Linux (Debian/Ubuntu)
sudo apt install qt6-base-dev libdcmtk-dev libopencv-dev libinsighttoolkit5-dev ninja-build
cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/xareviewer

# 测试
QT_QPA_PLATFORM=offscreen ctest --test-dir build --output-on-failure
```

macOS（Homebrew）：`brew install qt dcmtk opencv itk`，并配置
`-DCMAKE_PREFIX_PATH="$(brew --prefix qt);$(brew --prefix opencv);$(brew --prefix dcmtk);$(brew --prefix itk)"`。

Windows：使用 vcpkg manifest（见 `vcpkg.json`）：
`cmake -B build -DCMAKE_TOOLCHAIN_FILE=<vcpkg>/scripts/buildsystems/vcpkg.cmake`。

## 发布

推送 `v*` 标签触发 [CI](.github/workflows/release.yml) 自动构建并发布：

- Windows x64 便携版（exe + DLL，zip）
- macOS 应用（dmg）
